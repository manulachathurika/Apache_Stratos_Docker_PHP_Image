#!/bin/bash
# --------------------------------------------------------------
#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#
# --------------------------------------------------------------
# This extension script will be executed when member activated
# event is received.
# --------------------------------------------------------------
#

log=/var/log/apache-stratos/cartridge-agent-extensions.log
OUTPUT=`date`": Member Activated Event: "
OUTPUT="$OUTPUT MEMBER_ID: ${STRATOS_MEMBER_ID}, "
OUTPUT="$OUTPUT MEMBER_IP: ${STRATOS_MEMBER_IP}, "
OUTPUT="$OUTPUT CLUSTER_ID: ${STRATOS_CLUSTER_ID}, "
OUTPUT="$OUTPUT LB_CLUSTER_ID: ${STRATOS_LB_CLUSTER_ID}, "
OUTPUT="$OUTPUT NETWORK_PARTITION_ID: ${STRATOS_NETWORK_PARTITION_ID}, "
OUTPUT="$OUTPUT SERVICE_NAME: ${STRATOS_SERVICE_NAME}, "
OUTPUT="$OUTPUT PORTS: ${STRATOS_PORTS},"
OUTPUT="$OUTPUT STRATOS_LB_IP: ${STRATOS_LB_IP},"
OUTPUT="$OUTPUT STRATOS_LB_PUBLIC_IP: ${STRATOS_LB_PUBLIC_IP},"
OUTPUT="$OUTPUT APP_PATH: ${APP_PATH},"
OUTPUT="$OUTPUT STRATOS_PARAM_FILE_PATH: ${STRATOS_PARAM_FILE_PATH}"
echo $OUTPUT | tee -a $log
echo "Member List: ${STRATOS_MEMBER_LIST_JSON}" | tee -a $log
echo "Topology: ${STRATOS_TOPOLOGY_JSON}" | tee -a $log
echo "---------------" | tee -a $log
